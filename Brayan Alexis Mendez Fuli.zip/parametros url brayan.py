url = input("Ingresa una URL: ")

componentes = url.split("&")

for componente in componentes:
    if "=" in componente:
        param = componente.split("=")
        if len(param) == 2 and param[1]  != "":
            print(f"Valor vacío para el parámetro: {param[0]}")

regex = r"=([a-zA-Z0-9]+)"  
params = re.findall(regex, url)

print("Parámetros encontrados con regex:")
print(params)